CrystalClouds v3 - Final
=======================

Quick start:
1. npm install
2. Fill .env with your TOKEN and IDs
3. node deploy-commands.cjs  (to register slash commands)
4. node index.js

Folders:
- commands/: command files (130 templates)
- events/: ready, interactionCreate, guildMemberAdd (welcome)
- handlers/: command and event loaders
- utils/: embed and music helpers
