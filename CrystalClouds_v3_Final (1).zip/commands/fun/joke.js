const { SlashCommandBuilder } = require('discord.js');
const { fancyEmbed } = require('../../utils/embed');
module.exports = {
  data: new SlashCommandBuilder().setName('joke').setDescription('Crystal Clouds command: joke'),
  prefixName: 'joke',
  async execute(interaction, client) {
    const isPrefix = interaction?.isPrefix === true;
    const rep = fancyEmbed('info','joke','This is a default response for joke. Customize it.');
    if (isPrefix) return interaction.message.reply({ embeds: [rep] });
    return interaction.reply({ embeds: [rep] });
  }
};
