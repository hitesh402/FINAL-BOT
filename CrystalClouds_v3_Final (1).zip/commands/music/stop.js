const { SlashCommandBuilder } = require('discord.js');
const { fancyEmbed } = require('../../utils/embed');
module.exports = {
  data: new SlashCommandBuilder().setName('stop').setDescription('Crystal Clouds command: stop'),
  prefixName: 'stop',
  async execute(interaction, client) {
    const isPrefix = interaction?.isPrefix === true;
    const rep = fancyEmbed('info','stop','This is a default response for stop. Customize it.');
    if (isPrefix) return interaction.message.reply({ embeds: [rep] });
    return interaction.reply({ embeds: [rep] });
  }
};
