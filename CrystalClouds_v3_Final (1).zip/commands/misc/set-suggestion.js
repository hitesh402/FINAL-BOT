const { SlashCommandBuilder } = require('discord.js');
const { fancyEmbed } = require('../../utils/embed');
module.exports = {
  data: new SlashCommandBuilder().setName('set-suggestion').setDescription('Crystal Clouds command: set-suggestion'),
  prefixName: 'set',
  async execute(interaction, client) {
    const isPrefix = interaction?.isPrefix === true;
    const rep = fancyEmbed('info','set-suggestion','This is a default response for set-suggestion. Customize it.');
    if (isPrefix) return interaction.message.reply({ embeds: [rep] });
    return interaction.reply({ embeds: [rep] });
  }
};
