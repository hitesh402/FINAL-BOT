const { SlashCommandBuilder } = require('discord.js');
const { fancyEmbed } = require('../../utils/embed');
module.exports = {
  data: new SlashCommandBuilder().setName('giveaway-reroll').setDescription('Crystal Clouds command: giveaway-reroll'),
  prefixName: 'giveaway',
  async execute(interaction, client) {
    const isPrefix = interaction?.isPrefix === true;
    const rep = fancyEmbed('info','giveaway-reroll','This is a default response for giveaway-reroll. Customize it.');
    if (isPrefix) return interaction.message.reply({ embeds: [rep] });
    return interaction.reply({ embeds: [rep] });
  }
};
