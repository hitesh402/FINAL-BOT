const { SlashCommandBuilder } = require('discord.js');
const { fancyEmbed } = require('../../utils/embed');
module.exports = {
  data: new SlashCommandBuilder().setName('warnings').setDescription('Crystal Clouds command: warnings'),
  prefixName: 'warnings',
  async execute(interaction, client) {
    const isPrefix = interaction?.isPrefix === true;
    const rep = fancyEmbed('info','warnings','This is a default response for warnings. Customize it.');
    if (isPrefix) return interaction.message.reply({ embeds: [rep] });
    return interaction.reply({ embeds: [rep] });
  }
};
