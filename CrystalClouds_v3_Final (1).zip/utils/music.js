const { joinVoiceChannel, createAudioPlayer, createAudioResource, AudioPlayerStatus, getVoiceConnection } = require('@discordjs/voice');
const play = require('play-dl');
const { fancyEmbed } = require('./embed');

async function playTrack(client, guildId, voiceChannel, textChannel, query, requester) {
  let queue = client.musicQueue.get(guildId);
  if (!queue) {
    queue = { tracks: [], playing: false, connection: null, player: null, textChannel };
    client.musicQueue.set(guildId, queue);
  }
  let info;
  if (play.yt_validate(query)) {
    info = await play.video_info(query);
  } else {
    const search = await play.search(query, { limit: 1 });
    if (!search || search.length === 0) throw new Error('No results');
    info = await play.video_info(search[0].url);
  }
  const track = { title: info.video_details.title, url: info.video_details.url, duration: info.video_details.durationRaw, requester: requester.username || requester.tag };
  queue.tracks.push(track);
  if (!queue.playing) await startPlayer(client, guildId, voiceChannel);
  else await textChannel.send({ embeds: [fancyEmbed('info','Added to Queue', `**${track.title}** — requested by **${track.requester}**`)] });
}

async function startPlayer(client, guildId, voiceChannel) {
  const queue = client.musicQueue.get(guildId);
  if (!queue) return;
  const textChannel = queue.textChannel;
  const track = queue.tracks.shift();
  if (!track) {
    const conn = getVoiceConnection(guildId);
    if (conn) conn.destroy();
    client.musicQueue.delete(guildId);
    return;
  }

  const connection = joinVoiceChannel({
    channelId: voiceChannel.id,
    guildId,
    adapterCreator: voiceChannel.guild.voiceAdapterCreator
  });
  queue.connection = connection;

  const stream = await play.stream(track.url, { quality: 2 });
  const resource = createAudioResource(stream.stream, { inputType: stream.type });
  const player = createAudioPlayer();
  queue.player = player;
  player.play(resource);
  queue.playing = true;
  queue.current = track;

  player.on(AudioPlayerStatus.Idle, () => {
    queue.playing = false;
    startPlayer(client, guildId, voiceChannel).catch(console.error);
  });

  await textChannel.send({ embeds: [fancyEmbed('info','Now Playing', `**${track.title}**\nDuration: ${track.duration}\nRequested by: ${track.requester}`)] });
}

module.exports = { playTrack };
