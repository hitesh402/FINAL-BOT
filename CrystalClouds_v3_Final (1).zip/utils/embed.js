const { EmbedBuilder } = require('discord.js');
function fancyEmbed(type='default', title='', description='') {
  const colors = { success: process.env.EMBED_COLOR_1 || '#7CFFEA', error: '#FF7C7C', info: process.env.EMBED_COLOR_2 || '#A9A0FF', warning: '#FFD27C', default: process.env.EMBED_COLOR_3 || '#8C7CFF' };
  const emojis = { success: '✅', error: '❌', info: '💫', warning: '⚠️', default: '🌌' };
  return new EmbedBuilder().setTitle(`${emojis[type] || emojis.default} ${title}`).setDescription(description ? `> ${description}` : '').setColor(colors[type]||colors.default).setTimestamp().setFooter({ text: 'crystalclouds • 2025' });
}
module.exports = { fancyEmbed };
