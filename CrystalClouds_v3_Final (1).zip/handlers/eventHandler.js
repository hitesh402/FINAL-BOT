const fs = require('fs');
const path = require('path');

module.exports = (client) => {
  const eventsPath = path.join(__dirname, '../events');
  if (!fs.existsSync(eventsPath)) return;
  fs.readdirSync(eventsPath).forEach(file => {
    const handler = require(path.join(eventsPath, file));
    const eventName = file.split('.')[0];
    client.on(eventName, (...args) => handler(client, ...args));
    console.log('Loaded event:', eventName);
  });
};
