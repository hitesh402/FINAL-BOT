const fs = require('fs');
const path = require('path');

module.exports = (client) => {
  const commandsPath = path.join(__dirname, '../commands');
  if (!fs.existsSync(commandsPath)) return;
  for (const category of fs.readdirSync(commandsPath)) {
    const categoryPath = path.join(commandsPath, category);
    if (!fs.existsSync(categoryPath)) continue;
    const files = fs.readdirSync(categoryPath).filter(f => f.endsWith('.js'));
    for (const file of files) {
      const cmd = require(path.join(categoryPath, file));
      if (!cmd || !cmd.data || !cmd.execute) {
        console.warn('Invalid command:', file);
        continue;
      }
      client.commands.set(cmd.data.name, cmd);
      if (cmd.prefixName) client.prefixCommands.set(cmd.prefixName, cmd);
      console.log('Loaded command:', cmd.data.name);
    }
  }
};
