module.exports = async (client, message) => {
  if (message.author.bot || !message.guild) return;
  const prefix = process.env.PREFIX || '!';
  if (!message.content.startsWith(prefix)) return;
  const args = message.content.slice(prefix.length).trim().split(/\s+/);
  const name = args.shift().toLowerCase();
  const cmd = client.prefixCommands.get(name);
  if (!cmd) return;
  try {
    await cmd.execute({ isPrefix: true, message, args, client });
  } catch (err) {
    console.error('Prefix command error', err);
    message.reply('❌ Error executing command.');
  }
};
