module.exports = async (client, member) => {
  try {
    const fs = require('fs');
    const path = './data/autorole.json';
    let autoroleId = process.env.AUTOROLE_ID || null;
    if (fs.existsSync(path)) {
      const data = JSON.parse(fs.readFileSync(path));
      if (data[member.guild.id]) autoroleId = data[member.guild.id];
    }
    if (autoroleId) {
      const role = member.guild.roles.cache.get(autoroleId);
      if (role) await member.roles.add(role).catch(()=>{});
    }
    const { EmbedBuilder } = require('discord.js');
    const chId = process.env.WELCOME_CHANNEL_ID;
    const ch = chId ? member.guild.channels.cache.get(chId) : member.guild.systemChannel;
    if (!ch) return;
    let inviter = 'Unknown';
    let inviteCount = '0';
    try {
      const invites = await member.guild.invites.fetch();
      let used;
      for (const inv of invites.values()) if (inv.uses && inv.uses>0) used = inv;
      if (used) { inviter = used.inviter ? used.inviter.tag : 'Unknown'; const inviterInv = invites.filter(i=>i.inviter && i.inviter.id === (used.inviter? used.inviter.id : null)); let total=0; inviterInv.forEach(x=>total+=x.uses||0); inviteCount = total.toString(); }
    } catch (e) {}
    const memberCount = member.guild.memberCount;
    const now = new Date().toLocaleString('en-GB', { timeZone: 'Asia/Kolkata' });
    const embed = new EmbedBuilder()
      .setTitle(`╭ ・ ⌬ ・${member.user.tag} joined.`)
      .setDescription('●▬▬▬▬▬▬▬▬๑۩✰۩๑▬▬▬▬▬▬▬▬●\n✰・Member Joined At ' + now + '\n✰・Invited by ' + inviter + '\n✰・They have now ' + inviteCount + ' invites\n●▬▬▬▬▬▬▬▬๑۩✰۩๑▬▬▬▬▬▬▬▬●\n╰ ・ ⌬ ・crystalclouds │ BEST AND BUDGET FRIENDLY HOSTING has now ' + memberCount + ' members')
      .setColor(process.env.EMBED_COLOR_1 || '#00FFFF')
      .setTimestamp()
      .setFooter({ text: 'crystalclouds • Welcome' });
    await ch.send({ embeds: [embed] });
    // log join
    const logId = process.env.LOGS_CHANNEL_ID;
    if (logId) {
      const logCh = member.guild.channels.cache.get(logId);
      if (logCh) logCh.send({ embeds: [embed] });
    }
  } catch (err) {
    console.error('Welcome event error', err);
  }
};
