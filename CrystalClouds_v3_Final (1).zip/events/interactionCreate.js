module.exports = async (client, interaction) => {
  try {
    if (interaction.isChatInputCommand && interaction.isChatInputCommand()) {
      const cmd = client.commands.get(interaction.commandName);
      if (!cmd) return;
      await cmd.execute(interaction, client);
    } else if (interaction.isButton && interaction.isButton()) {
      const custom = interaction.customId;
      if (custom === 'cc_pause' || custom === 'cc_resume' || custom === 'cc_skip') {
        const name = custom.replace('cc_','');
        const cmd = client.commands.get(name);
        if (cmd && cmd.executeButton) return cmd.executeButton(interaction, client);
      }
    } else if (interaction.isStringSelectMenu && interaction.isStringSelectMenu()) {
      if (interaction.customId === 'cc_autorole_select') {
        const roleId = interaction.values[0];
        const fs = require('fs');
        const path = './data/autorole.json';
        let data = {};
        if (fs.existsSync(path)) data = JSON.parse(fs.readFileSync(path));
        data[interaction.guildId] = roleId;
        fs.writeFileSync(path, JSON.stringify(data, null, 2));
        await interaction.reply({ embeds: [require('../utils/embed').fancyEmbed('success','Autorole Set','Saved autorole.')], ephemeral: true });
      }
    }
  } catch (err) {
    console.error('Interaction error', err);
  }
};
